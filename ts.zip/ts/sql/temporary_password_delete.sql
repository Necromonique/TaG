delete from temporary_passwords where server_id = :server_id: and temporary_password_hash = :temporary_password_hash:;
