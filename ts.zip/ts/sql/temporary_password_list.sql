select * from temporary_passwords where server_id = :server_id:;
