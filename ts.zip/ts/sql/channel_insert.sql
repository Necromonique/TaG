insert into channels
( server_id,
  channel_parent_id ) 
VALUES 
( :server_id:,
  :parent_id: );
